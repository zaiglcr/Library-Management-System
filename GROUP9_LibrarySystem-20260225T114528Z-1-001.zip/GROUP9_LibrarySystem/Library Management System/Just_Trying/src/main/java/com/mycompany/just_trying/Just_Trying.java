/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.just_trying;

/**
 *
 * @author Admin
 */
public class Just_Trying {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
